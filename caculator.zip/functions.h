#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// ��
float func_plus(float x,float y);
// ��
float func_substract(float x, float y);
// ��
float func_multiply(float x, float y);
// �� 
float func_devide(float x, float y);
// �˷�
float func_power(float x);
// ����
float func_my_sqrt(float x);